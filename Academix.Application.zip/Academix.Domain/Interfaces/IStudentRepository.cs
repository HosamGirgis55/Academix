using Academix.Domain.Entities;

namespace Academix.Domain.Interfaces
{
    public interface IStudentRepository : IGenericRepository<Student>
    {
        
        
    }
} 