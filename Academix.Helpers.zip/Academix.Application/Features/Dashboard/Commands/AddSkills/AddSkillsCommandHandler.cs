﻿using System;
using System.Threading;
using System.Threading.Tasks;
using Academix.Application.Common.Interfaces;
using Academix.Application.Common.Models;
using Academix.Domain.Entities;
using Academix.Domain.Interfaces;
using MediatR;

namespace Academix.Application.Features.Dashboard.Commands.AddSkills
{
    public class AddSkillsCommandHandler : IRequestHandler<AddSkillsCommand, Result>
    {
        private readonly IUnitOfWork _unitOfWork;
        private readonly ILocalizationService _localizationService;

        public AddSkillsCommandHandler(
            IUnitOfWork unitOfWork,
            ILocalizationService localizationService)
        {
            _unitOfWork = unitOfWork;
            _localizationService = localizationService;
        }

        public async Task<Result> Handle(AddSkillsCommand request, CancellationToken cancellationToken)
        {
            try
            {
                // Check if skill already exists (case-insensitive)
                var existsAr = await _unitOfWork.Skills
                    .AnyAsync(s => s.NameAr.ToLower() == request.NameAr.ToLower());

                var existsEn = await _unitOfWork.Skills
                    .AnyAsync(s => s.NameEn.ToLower() == request.NameEn.ToLower());

                if (existsAr)
                {
                    var message = _localizationService.GetLocalizedString("SkillArAlreadyExists");
                    return Result.Failure(message);
                }

                if (existsEn)
                {
                    var message = _localizationService.GetLocalizedString("SkillEnAlreadyExists");
                    return Result.Failure(message);
                }

                // Create and save new skill
                var skill = new Skill
                {
                    NameAr = request.NameAr.Trim(),
                    NameEn = request.NameEn.Trim(),
                    CreatedAt = DateTime.UtcNow
                };

                await _unitOfWork.Skills.AddAsync(skill);
                await _unitOfWork.SaveChangesAsync(cancellationToken);

                var successMessage = _localizationService.GetLocalizedString("SkillAddedSuccessfully");
                return Result.Success(successMessage);
            }
            catch (Exception ex)
            {
                var errorMessage = _localizationService.GetLocalizedString("SkillAddFailed");
                return Result.Failure($"{errorMessage}: {ex.InnerException?.Message ?? ex.Message}");
            }
        }
    }
}
